// Popup templates for SABconnect++ (moved from inline script)

// Error template
window.popupTemplates = {
    errors: `<li class="error">
    <%= this.error %>
</li>`
};
