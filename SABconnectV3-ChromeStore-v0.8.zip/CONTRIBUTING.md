Sadly, there is no more 'main developer' working on this Chrome extension.
Past developers who worked on most of the code have now stopped working on it.

If you are interested in taking charge of this extension, let us know by opening a new issue.

Otherwise, keep the Pull requests coming; I (Guillaume Boudreau) will try to merge them and release new versions that include the changes on the Chrome Web Store ASAP.

Cheers.
